import { Address } from "./address";

export interface EditUser {
    userId:number,
    firstName:string,
	lastName:string,
	city:Address['city'],
	state:Address['state'],
	country:Address['country']
}