import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterUserComponent } from './register-user/register-user.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {RouterModule} from '@angular/router';
import { LoginUserComponent } from './login-user/login-user.component'
import {HttpClientModule} from'@angular/common/http';
import { UserWallComponent } from './user-wall/user-wall.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { MessagesComponent } from './messages/messages.component';
import { DisplayUserComponent } from './display-user/display-user.component';
import { FileSelectDirective } from 'ng2-file-upload';
import { ProfileComponent } from './profile/profile.component';
import { EditProfileComponent } from './profile/edit-profile/edit-profile.component';
import {MatButtonModule, MatCheckboxModule, MatFormFieldModule,MatInputModule, MatError, MatFormFieldControl, MatDatepickerModule, MatNativeDateModule, MatRadioModule} from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AllUsersComponent } from './AllUsers/all-users.component';
import { FriendRequestsComponent } from './friend-requests/friend-requests.component';


@NgModule({
  declarations: [
    AppComponent,
    RegisterUserComponent,
    LoginUserComponent,
    UserWallComponent,
    WelcomeComponent,
    UserProfileComponent,
    MessagesComponent,
    DisplayUserComponent,
    FileSelectDirective,
    ProfileComponent,
    EditProfileComponent,
    AllUsersComponent,
    FriendRequestsComponent
  ],
  
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    MatFormFieldModule,
    MatInputModule,
    ReactiveFormsModule,
    FormsModule,
    MatDatepickerModule,
    MatNativeDateModule,
    BrowserAnimationsModule,
    MatRadioModule,
    RouterModule.forRoot([
      {path: 'wall', component:UserWallComponent},
      {path:'welcome', component:WelcomeComponent},
      {path:'login', component:LoginUserComponent},
      {path:'',component:WelcomeComponent},
      {path:'messages', component:MessagesComponent},
      {path:'profile', component:UserProfileComponent},
      {path:'allUsers',component:AllUsersComponent},
      {path:'friendRequestsList',component:FriendRequestsComponent}
    ])
  ],
  providers: [
    
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }