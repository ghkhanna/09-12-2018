package com.cg.capbook.exceptions;

public class RequestAlreadySentException extends Exception {

}
