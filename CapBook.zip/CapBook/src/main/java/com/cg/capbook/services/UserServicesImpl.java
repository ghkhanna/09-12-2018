package com.cg.capbook.services;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.capbook.beans.User;
import com.cg.capbook.daoservices.FriendListDAO;
import com.cg.capbook.daoservices.FriendRequestDAO;
import com.cg.capbook.daoservices.SentRequestDAO;
import com.cg.capbook.daoservices.UserDAO;
import com.cg.capbook.exceptions.IncorrectPasswordException;
import com.cg.capbook.exceptions.RequestAlreadySentException;
import com.cg.capbook.exceptions.SameUserIdException;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;

@Component(value="userServices")
public class UserServicesImpl implements UserServices{
	
	int flag=0;
	int i=0;
	int j=0;
	
	@Autowired
	UserDAO userDao;
	@Autowired
	FriendListDAO friendListDao;
	@Autowired
	FriendRequestDAO friendRequestDao;
	@Autowired
	SentRequestDAO sentRequestDao;
	
	@Override
	public User registerUser(User user) {
		return userDao.save(user);
	}
	
	@Override
	public boolean userExists(User user) {
		return (userDao.findByEmail(user.getEmailId())!=null);
	}
	
	@Override
	public User getUserDetails(int userId) throws UserDetailsNotFoundException {
		return userDao.findById(userId).orElseThrow(()->
		new UserDetailsNotFoundException("user details are not found"));		
	}
	
	@Override
	public User editUserDetails(User user) {
		return userDao.save(user);
	}
	
	@Override
	public boolean deleteUserAccount(int userId) throws UserDetailsNotFoundException {
		userDao.findById(userId).orElseThrow(()->
		new UserDetailsNotFoundException("user details are not found"));
		userDao.deleteById(userId);
		return true;
	}
	
	@Override
	public List<User> getAllUserDetails() {
		return userDao.findAll();
	}
	
	@Override
	public User loginUser(String emailId, String password) throws IncorrectPasswordException, UserDetailsNotFoundException {
		User user = userDao.findByEmail(emailId);
		/*if(user==null)
			throw new UserDetailsNotFoundException("");
		else {
			if(password.equals(user.getPassword()))
				return user;
			else
				throw new IncorrectPasswordException("Incorrect password");
		}*/
		if(password.equals(user.getPassword()))
			return user;
		else
			throw new IncorrectPasswordException("Incorrect password");
	}

	@Override
	public User getUserId(String emailId) {
		return userDao.findByEmail(emailId);
	}
	
	@Override
	public boolean rejectRequest(int userIdSender, int userIdreceiver) throws UserDetailsNotFoundException {
		User userR= getUserDetails(userIdreceiver);
		User userS = getUserDetails(userIdSender);
		friendRequestDao.removeReceivedRequest(userIdSender, userIdreceiver);
		sentRequestDao.cancelRequestSent(userIdSender, userIdreceiver);
		
		/*ArrayList<Integer> sentRequestId= userS.getSentRequestId();
		ArrayList<Integer> requestId=userR.getRequestId();
		for(int j:requestId) {
			if(requestId.get(j)==userIdSender)
				requestId.set(j, 0);
		}
		for(int i:sentRequestId) {
			if(sentRequestId.get(i)==userIdrecieved) 
				sentRequestId.set(i, 0);
		}*/
		return false;
	}
	
	@Override
	public boolean cancelSentRequest(int userIdSender, int userIdreceiver) throws UserDetailsNotFoundException {
		User userS = getUserDetails(userIdSender);
		User userR= getUserDetails(userIdreceiver);
		sentRequestDao.cancelRequestSent(userIdSender, userIdreceiver);
		friendRequestDao.removeReceivedRequest(userIdSender, userIdreceiver);
		
		/*ArrayList<Integer> sentRequestId= userS.getSentRequestId();
		ArrayList<Integer> requestId=userR.getRequestId();
		for(int i:sentRequestId) {
			if(sentRequestId.get(i)==userIdrecieved) 
				sentRequestId.set(i, 0);
		}
		for(int j:requestId) {
			if(requestId.get(j)==userIdSender)
				requestId.set(j, 0);
		}*/
		return true;
	}
	
	@Override
	public boolean acceptFriendRequest(int userIdSender,int userIdreceiver) throws UserDetailsNotFoundException {
		User userS = getUserDetails(userIdSender);
		User userR= getUserDetails(userIdreceiver);
		friendListDao.requestGetsAccepted(userIdSender, userIdreceiver);
		friendListDao.acceptRequest(userIdSender, userIdreceiver);
		/*List<Integer> requestId = userR.getRequestId();
		for(int i : requestId) {
			if(userR.getRequestId().get(i)==userIdSender) {
				userR.getFriendId().add(userIdSender);
				userS.getFriendId().add(userIdreceiver);
		}}*/
		return true;
	}
	
	@Override
	public boolean sendFriendRequest(int userIdSender, int userIdreceiver) throws UserDetailsNotFoundException, SameUserIdException, RequestAlreadySentException {
		
		
		User userS = getUserDetails(userIdSender);
		User userR= getUserDetails(userIdreceiver);
		if(userIdSender!=userIdreceiver) {
		sentRequestDao.saveSentRequest(userIdSender, userIdreceiver);
		friendRequestDao.getRequest(userIdSender, userIdreceiver);
		}
		/*ArrayList<Integer> requestId = userR.getRequestId();
		ArrayList<Integer> sentRequestId= userS.getSentRequestId();
		if(flag==0) {
			sentRequestId.add(userIdreceiver);
			requestId.add(userIdSender);
			flag++;
		}
		if(userIdSender!=userIdreceiver) {
		for(int i:sentRequestId) {
			if(sentRequestId.get(i)!=userIdreceiver) {
				sentRequestId.add(userIdreceiver);
				requestId.add(userIdSender);
			}
			else throw new RequestAlreadySentException("request is already sent");
		}
		return true;
	}else throw new SameUserIdException("you can't send request to yourself dummy");*/
		
		return true;
		}

	@Override
	public List<User> getFriendsList(int userId, int friendId) {
	return userDao.getfriendsDetails(userId, friendId);
	}

	@Override
	public List<User> getFriendRequests(int userIdreceiver) throws UserDetailsNotFoundException {
		userDao.findById(userIdreceiver).orElseThrow(()->
		new UserDetailsNotFoundException("user id of receiver not found"));
		return userDao.getfriendRequests(userIdreceiver);
	}
	
	
}