package com.cg.capbook.exceptions;

public class IncorrectPasswordException extends Exception{

	public IncorrectPasswordException() {}

	public IncorrectPasswordException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {}

	public IncorrectPasswordException(String arg0, Throwable arg1) {}

	public IncorrectPasswordException(String arg0) {}

	public IncorrectPasswordException(Throwable arg0) {}

}
