package com.cg.capbook.beans;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity
public class SentRequest {
	@Id
	private int sentRequestId;
	@ManyToOne
	@JoinColumn(name="userId")
	private User user;
}
